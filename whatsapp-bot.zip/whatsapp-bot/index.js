import pkg from '@whiskeysockets/baileys';
import qrcode from 'qrcode-terminal';
import P from 'pino';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url'; // Para simular __dirname
import dotenv from 'dotenv';
import TelegramBot from 'node-telegram-bot-api';
import axios from 'axios'; // Para fazer requisições HTTP à API do GitHub

// Simular __dirname em ES Modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Carregar variáveis de ambiente desde .env
dotenv.config();

// Importações do Baileys
const { makeWASocket, useMultiFileAuthState, DisconnectReason, downloadContentFromMessage } = pkg;

// Logger para depuração (sem logs)
const logger = P({ level: 'silent' });

// Desativar avisos de depreciação do node-telegram-bot-api
process.env.NTBA_FIX_350 = 'true';

// Configuração do Telegram
const TELEGRAM_BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN; // Token do bot do Telegram
const telegramBot = new TelegramBot(TELEGRAM_BOT_TOKEN, { polling: true }); // Habilitar polling

// Variáveis de ambiente para o GitHub
const GITHUB_TOKEN = process.env.GITHUB_TOKEN;
const REPO_OWNER = process.env.REPO_OWNER;
const REPO_NAME = process.env.REPO_NAME;
const FILE_PATH = "index.html"; // Caminho do arquivo no repositório
const BRANCH = "main"; // Branch onde o arquivo será atualizado

// Conjunto para evitar processamento duplicado de mensagens
const processedMessages = new Set();

// Contador global para numerar os mensajes
let messageCounter = loadMessageCounter();

// Função para carregar o contador desde um archivo local
function loadMessageCounter() {
    const counterFilePath = 'message_counter.txt';
    if (fs.existsSync(counterFilePath)) {
        const counter = parseInt(fs.readFileSync(counterFilePath, 'utf-8'), 10);
        return isNaN(counter) ? 1 : counter;
    }
    return 1;
}

// Função para salvar o contador en un archivo local
function saveMessageCounter(counter) {
    const counterFilePath = 'message_counter.txt';
    fs.writeFileSync(counterFilePath, counter.toString(), 'utf-8');
}

// Função para extrair URLs
function extractURL(text) {
    const urlRegex = /https?:\/\/[^\s]+/g;
    const matches = text.match(urlRegex);
    return matches ? matches[0] : null;
}

// Função para formatar a mensagem em HTML
function formatMessage(messageText, imageLink, link) {
    const formattedMessage = `
    <div class="message">
        <p class="message-number">#${String(messageCounter).padStart(3, '0')}</p>
        ${imageLink ? `<img src="${imageLink}" alt="Imagen" class="message-image">` : ''}
        <p><strong>Enlace:</strong> <a href="${link}" target="_blank">${link}</a></p>
        <p class="description"><strong>Descripción:</strong>
            ${escapeHTML(messageText)}
            <a href="${link}" target="_blank" class="action-button">Comprar Agora</a>
        </p>
    </div>
    `;
    messageCounter++;
    saveMessageCounter(messageCounter);
    return formattedMessage;
}

// Função para escapar caracteres especiais em HTML
function escapeHTML(text) {
    return text.replace(/[&<>"']/g, (match) => ({
        '&': '&amp;',
        '<': '<',
        '>': '>',
        '"': '&quot;',
        "'": '&#39;'
    }[match]));
}

// Função para baixar imagens e retornar suas URLs
async function downloadImages(imageKeys, sock) {
    const imageUrls = [];
    for (const key of imageKeys) {
        const stream = await downloadContentFromMessage(key, 'image');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        const filename = `image_${Date.now()}.jpg`;
        fs.writeFileSync(filename, buffer);
        imageUrls.push(filename);
    }
    return imageUrls;
}

// Função para ler o conteúdo atual do arquivo index.html no GitHub
async function getFileContent() {
    const url = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`;
    const headers = { Authorization: `token ${GITHUB_TOKEN}` };
    try {
        const response = await axios.get(url, { headers });
        const content = response.data.content;
        return Buffer.from(content, 'base64').toString('utf-8'); // Decodificar Base64
    } catch (error) {
        return '';
    }
}

// Função para atualizar o arquivo index.html no GitHub
async function updateFile(newContent) {
    const url = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_PATH}`;
    const headers = { Authorization: `token ${GITHUB_TOKEN}` };
    try {
        const response = await axios.get(url, { headers });
        const sha = response.data.sha;
        const data = {
            message: "Atualização automática via bot",
            content: Buffer.from(newContent).toString('base64'), // Codificar em Base64
            sha: sha,
            branch: BRANCH,
        };
        await axios.put(url, data, { headers });
    } catch (error) {}
}

// Função principal para iniciar a conexão de WhatsApp
async function startBot() {
    try {
        const { state, saveCreds } = await useMultiFileAuthState('auth_info');
        const sock = makeWASocket({
            printQRInTerminal: false,
            auth: state,
            logger: logger,
        });

        sock.ev.on('creds.update', saveCreds);
        sock.ev.on('connection.update', async (update) => {
            const { connection, lastDisconnect, qr } = update;
            if (connection === 'close') {
                const shouldReconnect =
                    (lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut;
                if (shouldReconnect) {
                    setTimeout(startBot, 5000);
                }
            }
            if (connection === 'open') {}
            if (qr) {
                qrcode.generate(qr, { small: true });
            }
        });

        // Detectar mensagens e eventos no grupo
        sock.ev.on('messages.upsert', async (messageUpsert) => {
            try {
                const message = messageUpsert.messages[0];
                if (!message || !message.key || !message.key.id) return;

                const messageId = message.key.id;
                if (processedMessages.has(messageId)) {
                    return;
                }
                processedMessages.add(messageId);

                const { key, message: msg, pushName } = message;
                const sender = key.remoteJid;
                const messageText = msg?.conversation || msg?.text || '';
                const caption = msg?.imageMessage?.caption || msg?.videoMessage?.caption || '';
                const link = extractURL(messageText) || extractURL(caption) || '';

                let imageUrls = [];
                if (msg?.imageMessage) {
                    const mediaKey = [msg.imageMessage];
                    imageUrls = await downloadImages(mediaKey, sock);
                }

                if (link || caption || imageUrls.length > 0) {
                    const formattedMessage = `
#${String(messageCounter).padStart(3, '0')}
${caption || messageText}
Enlace: ${link}
`.trim();

                    const options = {
                        reply_markup: {
                            inline_keyboard: [
                                [
                                    {
                                        text: '👉 Compre Aqui',
                                        url: link,
                                    },
                                ],
                            ],
                        },
                    };

                    const CHAT_IDS_FILE = 'chat_ids.json';
                    let chatIds = [];
                    if (fs.existsSync(CHAT_IDS_FILE)) {
                        const data = fs.readFileSync(CHAT_IDS_FILE, 'utf-8');
                        try {
                            chatIds = JSON.parse(data);
                        } catch (err) {}
                    }

                    let imageLink = null;
                    for (const chatId of chatIds) {
                        if (imageUrls.length > 0) {
                            const imagePath = imageUrls[0];
                            const sentMessage = await telegramBot.sendPhoto(chatId, imagePath, {
                                caption: formattedMessage,
                                parse_mode: 'HTML',
                                ...options,
                                contentType: 'image/jpeg',
                            });
                            fs.unlinkSync(imagePath);
                            const fileId = sentMessage.photo[sentMessage.photo.length - 1].file_id;
                            const fileUrl = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/getFile?file_id=${fileId}`;
                            const fileResponse = await axios.get(fileUrl);
                            const filePath = fileResponse.data.result.file_path;
                            imageLink = `https://api.telegram.org/file/bot${TELEGRAM_BOT_TOKEN}/${filePath}`;
                        } else {
                            await telegramBot.sendMessage(chatId, formattedMessage, {
                                parse_mode: 'HTML',
                                ...options,
                            });
                        }
                    }

                    const currentContent = await getFileContent();
                    const newMessage = formatMessage(caption || messageText, imageLink, link);
                    const updatedContent = currentContent.replace('</body>', newMessage + '</body>');
                    await updateFile(updatedContent);
                }
            } catch (err) {}
        });

        // Detectar eventos de adição/remoção de participantes no grupo
        sock.ev.on('group-participants.update', async (update) => {
            try {
                const { id, participants, action } = update; // ID do grupo, participantes afetados e ação (add/remove)

                if (action === 'add') {
                    // Enviar mensagem de boas-vindas para cada novo participante
                    for (const participant of participants) {
                        const welcomeMessage = `
🌟 *Seja bem-vindo(a), @${participant.split('@')[0]}!* 🌟
🎉 Estamos muito felizes em tê-lo(a) conosco! Aqui você encontrará:
✅ *Produtos incríveis* com preços imbatíveis!
⚡️ Atendimento rápido e personalizado.
🎁 Promoções exclusivas para membros do grupo.
📱 *Conecte-se conosco nos nossos canais oficiais:*
🔗 Telegram: https://t.me/+KFEjEW4mmMQ5OGVh
🌐 Site: https://leticiasafu.github.io/Link/
📸 Instagram: https://www.instagram.com/promos_da_leleh?igsh=MTVhZGE5eWhrMHMweQ==
💡 *Dica:* Salve esses links para acessá-los sempre que precisar!
Se tiver dúvidas ou quiser conhecer nossos produtos, estamos à disposição! 😊
#BemVindo #OfertasImperdíveis
                        `.trim();

                        await sock.sendMessage(id, {
                            text: welcomeMessage,
                            mentions: [participant], // Marcar o novo participante
                        });
                    }
                }
            } catch (err) {}
        });

        // Registrar novos chats do Telegram
        telegramBot.on('message', (msg) => {
            const chatId = msg.chat.id;
            const CHAT_IDS_FILE = 'chat_ids.json';
            let chatIds = [];
            if (fs.existsSync(CHAT_IDS_FILE)) {
                const data = fs.readFileSync(CHAT_IDS_FILE, 'utf-8');
                try {
                    chatIds = JSON.parse(data);
                } catch (err) {}
            }
            if (!chatIds.includes(chatId)) {
                chatIds.push(chatId);
                fs.writeFileSync(CHAT_IDS_FILE, JSON.stringify(chatIds), 'utf-8');
            }
        });
    } catch (err) {}
}

startBot();